import os
import random
import torch
import cv2
import numpy as np
import pandas as pd
from torchvision import models, transforms
from PIL import Image
from pytorch_grad_cam import GradCAM
from pytorch_grad_cam.utils.image import show_cam_on_image
from pytorch_grad_cam.utils.model_targets import ClassifierOutputTarget

# -----------------------------
# CONFIG
# -----------------------------
MODEL_PATH = r"C:\Users\Janvi\OneDrive\Desktop\Sem_8_Project\checkpoints\image_resnet\resnet50_image.pth"
TSV_PATH   = r"C:\Users\Janvi\OneDrive\Desktop\Sem_8_Project\dataset\Fakeddit\tsv\image_test_balanced.tsv"

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

NUM_SAMPLES = 5
IMG_SIZE = 350
BANNER_HEIGHT = 50

LABEL_MAP = {0: "REAL", 1: "FAKE"}

# -----------------------------
# LOAD MODEL (ResNet-50)
# -----------------------------
model = models.resnet50(weights=None)
model.fc = torch.nn.Linear(model.fc.in_features, 2)

state_dict = torch.load(MODEL_PATH, map_location=DEVICE)
model.load_state_dict(state_dict)

model.to(DEVICE)
model.eval()

# Grad-CAM target layer (ResNet-50)
target_layers = [model.layer4[-1]]
cam = GradCAM(model=model, target_layers=target_layers)

# -----------------------------
# TRANSFORM
# -----------------------------
transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize(
        mean=[0.485, 0.456, 0.406],
        std =[0.229, 0.224, 0.225]
    )
])

# -----------------------------
# EXPLAIN FUNCTION
# -----------------------------
def explain_samples():
    df = pd.read_csv(TSV_PATH, sep="\t")
    indices = random.sample(range(len(df)), NUM_SAMPLES)

    for i, idx in enumerate(indices, 1):
        row = df.iloc[idx]

        image_path = row["image_path"]
        actual_label = LABEL_MAP[row["2_way_label"]]

        img = Image.open(image_path).convert("RGB")
        img_tensor = transform(img).unsqueeze(0).to(DEVICE)

        # -----------------
        # Prediction
        # -----------------
        with torch.no_grad():
            outputs = model(img_tensor)
            probs = torch.softmax(outputs, dim=1)
            pred = torch.argmax(probs, dim=1).item()

        predicted_label = LABEL_MAP[pred]
        confidence = probs[0][pred].item()

        # -----------------
        # Grad-CAM
        # -----------------
        targets = [ClassifierOutputTarget(pred)]
        grayscale_cam = cam(input_tensor=img_tensor, targets=targets)[0]

        # Prepare images
        original_img = np.array(img.resize((IMG_SIZE, IMG_SIZE)))
        original_img = cv2.cvtColor(original_img, cv2.COLOR_RGB2BGR)

        cam_base = np.array(img.resize((224, 224))).astype(np.float32) / 255.0
        cam_img = show_cam_on_image(cam_base, grayscale_cam, use_rgb=True)
        cam_img = cv2.resize(cam_img, (IMG_SIZE, IMG_SIZE))

        # Combine images
        image_row = np.hstack((original_img, cam_img))
        h, w, _ = image_row.shape

        # Banner color
        is_correct = actual_label == predicted_label
        banner_color = (180, 255, 180) if is_correct else (180, 180, 255)

        banner = np.full((BANNER_HEIGHT, w, 3), banner_color, dtype=np.uint8)

        # Banner text
        label_text = (
            f"Actual: {actual_label} | "
            f"Predicted: {predicted_label} | "
            f"Confidence: {confidence:.2f}"
        )

        cv2.putText(
            banner,
            label_text,
            (20, 32),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.6,
            (0, 0, 0),
            2
        )

        final_frame = np.vstack((banner, image_row))

        # -----------------
        # LOGS
        # -----------------
        print("\n" + "="*100)
        print(f"Sample {i}/{NUM_SAMPLES}")
        print(f"Image Path      : {image_path}")
        print(f"Actual Label    : {actual_label}")
        print(f"Predicted Label : {predicted_label}")
        print(f"Confidence      : {confidence:.4f}")

        cv2.imshow("Original (Left) | Grad-CAM (Right)", final_frame)
        key = cv2.waitKey(0)

        if key == 27:  # ESC
            break

    cv2.destroyAllWindows()
    print("\nImage explainability completed.")

# -----------------------------
# ENTRY POINT
# -----------------------------
if __name__ == "__main__":
    explain_samples()
