import pandas as pd

# Load datasets
train_df = pd.read_csv(r'C:\Users\Janvi\OneDrive\Desktop\Sem_8_Project\dataset\fakeddit\train_balanced.tsv', sep='\t')
val_df   = pd.read_csv(r'C:\Users\Janvi\OneDrive\Desktop\Sem_8_Project\dataset\fakeddit\val_final.tsv', sep='\t')
test_df  = pd.read_csv(r'C:\Users\Janvi\OneDrive\Desktop\Sem_8_Project\dataset\fakeddit\test_final.tsv', sep='\t')

# -----------------------------
# Standardize train dataset
# -----------------------------
train_df.rename(columns={'text': 'clean_title', 'label': '2_way_label'}, inplace=True)
train_df['language'] = 'en'

# Keep only necessary columns
train_df = train_df[['clean_title', '2_way_label', 'image_path', 'language']]

# -----------------------------
# Standardize val dataset
# -----------------------------
# Rename image column first
val_df.rename(columns={'image_url': 'image_path'}, inplace=True)
# Add language column
val_df['language'] = 'en'
# Keep only necessary columns
val_df = val_df[['clean_title', '2_way_label', 'image_path', 'language']]

# -----------------------------
# Standardize test dataset
# -----------------------------
# Rename image column first
test_df.rename(columns={'image_url': 'image_path'}, inplace=True)
# Add language column
test_df['language'] = 'en'
# Keep only necessary columns
test_df = test_df[['clean_title', '2_way_label', 'image_path', 'language']]

# -----------------------------
# Save standardized datasets (optional)
# -----------------------------
train_df.to_csv(r'C:\Users\Janvi\OneDrive\Desktop\Sem_8_Project\dataset\fakeddit\train_standardized.tsv', sep='\t', index=False)
val_df.to_csv(r'C:\Users\Janvi\OneDrive\Desktop\Sem_8_Project\dataset\fakeddit\val_standardized.tsv', sep='\t', index=False)
test_df.to_csv(r'C:\Users\Janvi\OneDrive\Desktop\Sem_8_Project\dataset\fakeddit\test_standardized.tsv', sep='\t', index=False)

print("English datasets standardized successfully")
