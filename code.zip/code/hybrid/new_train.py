import os
import warnings
warnings.filterwarnings("ignore", category=UserWarning)

import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader

import pandas as pd
from PIL import Image
from tqdm import tqdm

from transformers import AutoTokenizer, AutoModel
from torchvision import models, transforms

# ===================== CONFIG =====================
TRAIN_FILE = r"C:\Users\Janvi\OneDrive\Desktop\Sem_8_Project\dataset\fakeddit\tsv\train_hybrid.tsv"
VAL_FILE   = r"C:\Users\Janvi\OneDrive\Desktop\Sem_8_Project\dataset\fakeddit\tsv\val_hybrid.tsv"

BATCH_SIZE = 8
EPOCHS = 5
LR = 2e-5
MAX_LEN = 96

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("Using device:", DEVICE)

# ===================== IMAGE TRANSFORMS =====================
image_transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize(
        mean=[0.485, 0.456, 0.406],
        std =[0.229, 0.224, 0.225]
    )
])

# ===================== DATASET =====================
class HybridDataset(Dataset):
    def __init__(self, tsv_file):
        self.df = pd.read_csv(tsv_file, sep="\t")
        self.tokenizer = AutoTokenizer.from_pretrained("xlm-roberta-base")

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]

        encoding = self.tokenizer(
            str(row["text_multilingual"]),
            padding="max_length",
            truncation=True,
            max_length=MAX_LEN,
            return_tensors="pt"
        )

        img = Image.open(row["image_path"]).convert("RGB")
        img = image_transform(img)

        label = torch.tensor(row["2_way_label"], dtype=torch.long)

        return {
            "input_ids": encoding["input_ids"].squeeze(0),
            "attention_mask": encoding["attention_mask"].squeeze(0),
            "image": img,
            "label": label
        }

# ===================== MODELS =====================
class TextModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.encoder = AutoModel.from_pretrained("xlm-roberta-base")
        self.fc = nn.Linear(768, 2)

    def forward(self, input_ids, attention_mask):
        out = self.encoder(input_ids=input_ids, attention_mask=attention_mask)
        cls = out.last_hidden_state[:, 0]
        return self.fc(cls)

class ImageModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.backbone = models.resnet50(weights="IMAGENET1K_V1")
        self.backbone.fc = nn.Linear(2048, 2)

    def forward(self, x):
        return self.backbone(x)

# ===================== LOADERS (WINDOWS SAFE) =====================
train_loader = DataLoader(
    HybridDataset(TRAIN_FILE),
    batch_size=BATCH_SIZE,
    shuffle=True,
    num_workers=0
)

val_loader = DataLoader(
    HybridDataset(VAL_FILE),
    batch_size=BATCH_SIZE,
    shuffle=False,
    num_workers=0
)

# ===================== INIT =====================
text_model = TextModel().to(DEVICE)
image_model = ImageModel().to(DEVICE)

# ---- class weights (important for accuracy) ----
df_train = pd.read_csv(TRAIN_FILE, sep="\t")
class_counts = df_train["2_way_label"].value_counts().sort_index()
weights = 1.0 / class_counts
weights = torch.tensor(weights.values, dtype=torch.float).to(DEVICE)

criterion = nn.CrossEntropyLoss(weight=weights)

optimizer = torch.optim.AdamW(
    list(text_model.parameters()) + list(image_model.parameters()),
    lr=LR
)

# ===================== TRAIN =====================
best_acc = 0.0

for epoch in range(EPOCHS):
    print(f"\n========== EPOCH {epoch+1}/{EPOCHS} ==========")

    text_model.train()
    image_model.train()

    total_loss = 0.0

    for batch in tqdm(train_loader, desc="Training"):
        optimizer.zero_grad()

        input_ids = batch["input_ids"].to(DEVICE)
        attention_mask = batch["attention_mask"].to(DEVICE)
        images = batch["image"].to(DEVICE)
        labels = batch["label"].to(DEVICE)

        text_logits = text_model(input_ids, attention_mask)
        image_logits = image_model(images)

        # ---- DECISION FUSION ----
        fused_logits = (text_logits + image_logits) / 2

        loss = criterion(fused_logits, labels)
        loss.backward()
        optimizer.step()

        total_loss += loss.item()

    print(f"Train Loss: {total_loss / len(train_loader):.4f}")

    # ===================== VALIDATION =====================
    text_model.eval()
    image_model.eval()

    correct, total = 0, 0

    with torch.no_grad():
        for batch in tqdm(val_loader, desc="Validation"):
            input_ids = batch["input_ids"].to(DEVICE)
            attention_mask = batch["attention_mask"].to(DEVICE)
            images = batch["image"].to(DEVICE)
            labels = batch["label"].to(DEVICE)

            text_logits = text_model(input_ids, attention_mask)
            image_logits = image_model(images)

            fused_logits = (text_logits + image_logits) / 2
            preds = torch.argmax(fused_logits, dim=1)

            correct += (preds == labels).sum().item()
            total += labels.size(0)

    acc = correct / total
    print(f"Validation Accuracy: {acc:.4f}")

    if acc > best_acc:
        best_acc = acc
        torch.save({
            "text_model": text_model.state_dict(),
            "image_model": image_model.state_dict()
        }, "decision_fusion_best.pth")
        print("Best model saved")

print("\nTraining Completed Successfully")
