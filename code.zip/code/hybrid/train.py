import os
import torch
import pandas as pd
import numpy as np
from PIL import Image
from tqdm import tqdm

from torch.utils.data import Dataset, DataLoader
from transformers import XLMRobertaTokenizer
from torchvision import transforms

from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

from model import MultimodalFakeNewsModel

# =====================================================
# CONFIG
# =====================================================
TRAIN_FILE = r"C:\Users\Janvi\OneDrive\Desktop\Sem_8_Project\dataset\Fakeddit\tsv\train_hybrid.tsv"
VAL_FILE   = r"C:\Users\Janvi\OneDrive\Desktop\Sem_8_Project\dataset\Fakeddit\tsv\val_hybrid.tsv"
TEST_FILE  = r"C:\Users\Janvi\OneDrive\Desktop\Sem_8_Project\dataset\Fakeddit\tsv\test_hybrid.tsv"

MODEL_NAME = "xlm-roberta-base"
OUTPUT_DIR = "checkpoints/hybrid_model"
os.makedirs(OUTPUT_DIR, exist_ok=True)

MAX_LEN = 128
BATCH_SIZE = 4
EPOCHS = 6
LR = 1e-4

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# =====================================================
# TOKENIZER
# =====================================================
tokenizer = XLMRobertaTokenizer.from_pretrained(MODEL_NAME)

# =====================================================
# IMAGE TRANSFORMS
# =====================================================
image_transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize(
        mean=[0.485, 0.456, 0.406],
        std=[0.229, 0.224, 0.225]
    )
])

# =====================================================
# DATASET
# =====================================================
class HybridDataset(Dataset):
    def __init__(self, tsv_file):
        self.df = pd.read_csv(tsv_file, sep="\t")

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]

        # -------- TEXT --------
        encoding = tokenizer(
            str(row["text_multilingual"]),
            truncation=True,
            max_length=MAX_LEN,
            padding="max_length",
            return_tensors="pt"
        )

        # -------- IMAGE --------
        image = Image.open(row["image_path"]).convert("RGB")
        image = image_transform(image)

        return {
            "input_ids": encoding["input_ids"].squeeze(0),
            "attention_mask": encoding["attention_mask"].squeeze(0),
            "image": image,
            "label": torch.tensor(row["2_way_label"], dtype=torch.long)
        }

# =====================================================
# LOAD DATA
# =====================================================
train_loader = DataLoader(
    HybridDataset(TRAIN_FILE),
    batch_size=BATCH_SIZE,
    shuffle=True
)

val_loader = DataLoader(
    HybridDataset(VAL_FILE),
    batch_size=BATCH_SIZE,
    shuffle=False
)

test_loader = DataLoader(
    HybridDataset(TEST_FILE),
    batch_size=BATCH_SIZE,
    shuffle=False
)

# =====================================================
# MODEL
# =====================================================
model = MultimodalFakeNewsModel(MODEL_NAME).to(DEVICE)

optimizer = torch.optim.AdamW(
    filter(lambda p: p.requires_grad, model.parameters()),
    lr=LR,
    weight_decay=0.01
)

# =====================================================
# TRAINING LOOP
# =====================================================
best_val_f1 = 0.0

for epoch in range(EPOCHS):
    model.train()
    train_losses = []

    print(f"\n===== Epoch {epoch+1}/{EPOCHS} =====")

    for batch in tqdm(train_loader):
        optimizer.zero_grad()

        outputs = model(
            input_ids=batch["input_ids"].to(DEVICE),
            attention_mask=batch["attention_mask"].to(DEVICE),
            images=batch["image"].to(DEVICE),
            labels=batch["label"].to(DEVICE)
        )

        loss = outputs["loss"]
        loss.backward()
        optimizer.step()

        train_losses.append(loss.item())

    print(f"Train Loss: {np.mean(train_losses):.4f}")

    # ================= VALIDATION =================
    model.eval()
    preds, labels = [], []

    with torch.no_grad():
        for batch in val_loader:
            outputs = model(
                input_ids=batch["input_ids"].to(DEVICE),
                attention_mask=batch["attention_mask"].to(DEVICE),
                images=batch["image"].to(DEVICE)
            )

            logits = outputs["logits"]
            preds.extend(torch.argmax(logits, dim=1).cpu().numpy())
            labels.extend(batch["label"].numpy())

    val_f1 = f1_score(labels, preds)
    print(f"Validation F1: {val_f1:.4f}")

    # ================= SAVE BEST =================
    if val_f1 > best_val_f1:
        best_val_f1 = val_f1
        torch.save(model.state_dict(), os.path.join(OUTPUT_DIR, "best_hybrid_model.pth"))
        print("Best model saved")

# =====================================================
# TEST EVALUATION
# =====================================================
print("\n===== FINAL TEST EVALUATION =====")

model.load_state_dict(torch.load(os.path.join(OUTPUT_DIR, "best_hybrid_model.pth")))
model.eval()

preds, labels = [], []

with torch.no_grad():
    for batch in test_loader:
        outputs = model(
            input_ids=batch["input_ids"].to(DEVICE),
            attention_mask=batch["attention_mask"].to(DEVICE),
            images=batch["image"].to(DEVICE)
        )

        logits = outputs["logits"]
        preds.extend(torch.argmax(logits, dim=1).cpu().numpy())
        labels.extend(batch["label"].numpy())

print(f"Accuracy : {accuracy_score(labels, preds):.4f}")
print(f"Precision: {precision_score(labels, preds):.4f}")
print(f"Recall   : {recall_score(labels, preds):.4f}")
print(f"F1-score : {f1_score(labels, preds):.4f}")
