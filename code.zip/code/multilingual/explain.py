import torch
import pandas as pd
import numpy as np
import random
from transformers import XLMRobertaTokenizer, XLMRobertaForSequenceClassification

# =====================================================
# CONFIG
# =====================================================
MODEL_DIR = r"C:\Users\Janvi\OneDrive\Desktop\Sem_8_Project\checkpoints\text_multilingual_advanced"
TEST_FILE = r"C:\Users\Janvi\OneDrive\Desktop\Sem_8_Project\dataset\Fakeddit\tsv\test_multilingual.tsv"

OUTPUT_HTML = "multilingual_explanations_1.html"

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
MAX_LEN = 128
NUM_SAMPLES = 6

# =====================================================
# LOAD MODEL
# =====================================================
tokenizer = XLMRobertaTokenizer.from_pretrained(MODEL_DIR)
model = XLMRobertaForSequenceClassification.from_pretrained(
    MODEL_DIR,
    attn_implementation="eager"
)
model.to(DEVICE)
model.eval()

# =====================================================
# LOAD DATA
# =====================================================
df = pd.read_csv(TEST_FILE, sep="\t")

assert "text_multilingual" in df.columns, "text_multilingual column missing!"
assert "language" in df.columns, "language column missing!"

# =====================================================
# EXPLANATION FUNCTION
# =====================================================
def explain_text(text):
    inputs = tokenizer(
        text,
        return_tensors="pt",
        truncation=True,
        max_length=MAX_LEN
    ).to(DEVICE)

    with torch.no_grad():
        outputs = model(**inputs, output_attentions=True)

    probs = torch.softmax(outputs.logits, dim=1).cpu().numpy()[0]
    pred = int(np.argmax(probs))

    # Attention-based token importance
    attn = outputs.attentions[-1]          # last layer
    attn = attn.mean(dim=1).mean(dim=1)    # avg heads + tokens
    attn = attn.squeeze().cpu().numpy()

    tokens = tokenizer.convert_ids_to_tokens(inputs["input_ids"][0])

    cleaned_tokens = []
    for tok, score in zip(tokens, attn):
        if tok in ["<s>", "</s>", "<pad>"]:
            continue
        cleaned_tokens.append((tok.replace("▁", " "), float(score)))

    top_tokens = sorted(cleaned_tokens, key=lambda x: x[1], reverse=True)[:10]

    return pred, probs, top_tokens

# =====================================================
# HTML GENERATION
# =====================================================
html = """
<html>
<head>
<style>
body { font-family: Arial; background:#f4f6f8; padding:20px; }
.card { background:white; padding:20px; margin-bottom:20px;
        border-radius:10px; box-shadow:0 4px 8px rgba(0,0,0,0.1); }
.fake { color:#c0392b; font-weight:bold; }
.real { color:#27ae60; font-weight:bold; }
.token { display:inline-block; margin:4px; padding:6px 10px;
         background:#ecf0f1; border-radius:6px; }
.conf { font-size:14px; color:#555; }
.lang { font-size:13px; color:#888; }
</style>
</head>
<body>

<h1>Multilingual Fake News Explainability</h1>
"""

samples = random.sample(range(len(df)), NUM_SAMPLES)

for idx in samples:
    row = df.iloc[idx]

    text = row["text_multilingual"]
    language = row["language"]

    pred, probs, tokens = explain_text(text)

    actual = "Fake" if row["2_way_label"] == 1 else "Real"
    predicted = "Fake" if pred == 1 else "Real"

    html += f"""
    <div class="card">
        <p><b>Text:</b> {text}</p>
        <p class="lang">Language: {language}</p>
        <p>Actual: <span class="{actual.lower()}">{actual}</span></p>
        <p>Predicted: <span class="{predicted.lower()}">{predicted}</span></p>
        <p class="conf">Confidence → Real: {probs[0]:.3f} | Fake: {probs[1]:.3f}</p>

        <p><b>Important Tokens:</b></p>
    """

    for tok, score in tokens:
        html += f'<span class="token">{tok} ({score:.2f})</span>'

    html += "</div>"

html += "</body></html>"

with open(OUTPUT_HTML, "w", encoding="utf-8") as f:
    f.write(html)

print(f"\nMultilingual explainability HTML saved to: {OUTPUT_HTML}")
