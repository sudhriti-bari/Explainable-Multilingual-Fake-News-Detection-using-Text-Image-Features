import pandas as pd
import torch
from torch.utils.data import Dataset
from PIL import Image
import os
from transformers import XLMRobertaTokenizer
from torchvision import transforms

tokenizer = XLMRobertaTokenizer.from_pretrained("xlm-roberta-base")

img_tfms = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
])

class FakedditDataset(Dataset):
    def __init__(self, tsv_path, image_dir):
        self.df = pd.read_csv(tsv_path, sep="\t")
        self.image_dir = image_dir

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]

        text = str(row["clean_title"])
        label = int(row["2_way_label"])

        encoding = tokenizer(
            text,
            padding="max_length",
            truncation=True,
            max_length=128,
            return_tensors="pt"
        )

        img_path = os.path.join(self.image_dir, row["image_id"] + ".jpg")
        image = Image.open(img_path).convert("RGB")
        image = img_tfms(image)

        return {
            "input_ids": encoding["input_ids"].squeeze(0),
            "attention_mask": encoding["attention_mask"].squeeze(0),
            "image": image,
            "label": torch.tensor(label)
        }
