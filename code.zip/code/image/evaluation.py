import torch
import torch.nn as nn
import pandas as pd
from torch.utils.data import DataLoader
from torchvision import models, transforms
from PIL import Image
from sklearn.metrics import accuracy_score, classification_report

# -----------------------
# CONFIG
# -----------------------
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

VAL_TSV = r"C:\Users\Janvi\OneDrive\Desktop\Sem_8_Project\dataset\Fakeddit\tsv\image_val_balanced.tsv"
MODEL_PATH = r"C:\Users\Janvi\OneDrive\Desktop\Sem_8_Project\checkpoints\image_resnet\resnet50_image.pth"

BATCH_SIZE = 32

# -----------------------
# DATASET
# -----------------------
class ImageDataset(torch.utils.data.Dataset):
    def __init__(self, tsv_path, transform):
        self.df = pd.read_csv(tsv_path, sep="\t")
        self.transform = transform

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        image = Image.open(row["image_path"]).convert("RGB")
        label = int(row["2_way_label"])
        return self.transform(image), label

# -----------------------
# TRANSFORMS (same as training)
# -----------------------
transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize(
        mean=[0.485, 0.456, 0.406],
        std=[0.229, 0.224, 0.225]
    )
])

# -----------------------
# DATALOADER (Windows safe)
# -----------------------
dataset = ImageDataset(VAL_TSV, transform)
loader = DataLoader(
    dataset,
    batch_size=BATCH_SIZE,
    shuffle=False,
    num_workers=0
)

# -----------------------
# LOAD RESNET-50 MODEL
# -----------------------
model = models.resnet50(weights=None)

# Replace final FC layer (ResNet uses `fc`, not `classifier`)
model.fc = nn.Linear(model.fc.in_features, 2)

# Load trained weights
state_dict = torch.load(MODEL_PATH, map_location=DEVICE)
model.load_state_dict(state_dict)

model.to(DEVICE)
model.eval()

# -----------------------
# EVALUATION
# -----------------------
all_preds = []
all_labels = []

with torch.no_grad():
    for images, labels in loader:
        images = images.to(DEVICE)
        labels = labels.to(DEVICE)

        outputs = model(images)
        preds = torch.argmax(outputs, dim=1)

        all_preds.extend(preds.cpu().numpy())
        all_labels.extend(labels.cpu().numpy())

# -----------------------
# METRICS
# -----------------------
print("\n===== IMAGE MODEL VALIDATION RESULTS =====\n")

print("Accuracy:", accuracy_score(all_labels, all_preds))

print("\nClassification Report:\n")
print(classification_report(
    all_labels,
    all_preds,
    target_names=["REAL", "FAKE"]
))
