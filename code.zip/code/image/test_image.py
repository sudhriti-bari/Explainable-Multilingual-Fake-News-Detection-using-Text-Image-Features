import pandas as pd
import torch
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms, models
from PIL import Image
import torch.nn as nn
from sklearn.metrics import (
    accuracy_score,
    precision_recall_fscore_support,
    confusion_matrix,
    classification_report
)
from tqdm import tqdm

# -----------------------------
# CONFIG
# -----------------------------
TEST_TSV = r"C:\Users\Janvi\OneDrive\Desktop\Sem_8_Project\dataset\Fakeddit\tsv\image_test_balanced.tsv"
MODEL_PATH = r"C:\Users\Janvi\OneDrive\Desktop\Sem_8_Project\checkpoints\image_only\best_image_model.pth"

BATCH_SIZE = 32
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

# -----------------------------
# DATASET
# -----------------------------
class ImageDataset(Dataset):
    def __init__(self, df):
        self.df = df.reset_index(drop=True)
        self.transform = transforms.Compose([
            transforms.Resize((224, 224)),
            transforms.ToTensor(),
            transforms.Normalize(
                mean=[0.485, 0.456, 0.406],
                std =[0.229, 0.224, 0.225]
            )
        ])

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        image = Image.open(row["image_path"]).convert("RGB")
        label = int(row["2_way_label"])
        return self.transform(image), label

# -----------------------------
# LOAD DATA
# -----------------------------
test_df = pd.read_csv(TEST_TSV, sep="\t")
test_loader = DataLoader(
    ImageDataset(test_df),
    batch_size=BATCH_SIZE,
    shuffle=False
)

print(f"Test samples: {len(test_df)}")

# -----------------------------
# LOAD MODEL
# -----------------------------
model = models.resnet18(pretrained=False)
model.fc = nn.Linear(model.fc.in_features, 2)
model.load_state_dict(torch.load(MODEL_PATH, map_location=DEVICE))
model.to(DEVICE)
model.eval()

# -----------------------------
# TESTING
# -----------------------------
all_preds = []
all_labels = []

with torch.no_grad():
    for images, labels in tqdm(test_loader, desc="Testing Image Model"):
        images, labels = images.to(DEVICE), labels.to(DEVICE)
        outputs = model(images)
        preds = torch.argmax(outputs, dim=1)

        all_preds.extend(preds.cpu().numpy())
        all_labels.extend(labels.cpu().numpy())

# -----------------------------
# METRICS
# -----------------------------
acc = accuracy_score(all_labels, all_preds)

precision, recall, f1, _ = precision_recall_fscore_support(
    all_labels, all_preds, average="weighted"
)

classwise = precision_recall_fscore_support(
    all_labels, all_preds, average=None
)

cm = confusion_matrix(all_labels, all_preds)

print("\n===== IMAGE-ONLY TEST RESULTS =====")
print(f"Accuracy : {acc:.4f}")
print(f"Precision: {precision:.4f}")
print(f"Recall   : {recall:.4f}")
print(f"F1-score : {f1:.4f}")

print("\n--- Class-wise Metrics [REAL (0), FAKE (1)] ---")
print("Precision:", classwise[0])
print("Recall   :", classwise[1])
print("F1-score :", classwise[2])

print("\n--- Confusion Matrix ---")
print(cm)

print("\n--- Classification Report ---")
print(classification_report(
    all_labels,
    all_preds,
    target_names=["REAL", "FAKE"]
))
