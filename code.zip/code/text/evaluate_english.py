import pandas as pd
import torch
from torch.utils.data import DataLoader, Dataset
from transformers import XLMRobertaTokenizer, XLMRobertaForSequenceClassification
from sklearn.metrics import accuracy_score, precision_recall_fscore_support

# -----------------------------
# Paths
# -----------------------------
MODEL_PATH = r"C:\Users\Janvi\OneDrive\Desktop\Sem_8_Project\checkpoints\epoch_2"
TEST_PATH  = r"C:\Users\Janvi\OneDrive\Desktop\Sem_8_Project\dataset\fakeddit\tsv\test_standardized.tsv"

# -----------------------------
# Load test dataset
# -----------------------------
test_df = pd.read_csv(TEST_PATH, sep="\t")
print(f"Test samples: {len(test_df)}")

# -----------------------------
# Dataset class
# -----------------------------
class NewsDataset(Dataset):
    def __init__(self, df, tokenizer, max_len=128):
        self.texts = df["clean_title"].astype(str).tolist()
        self.labels = df["2_way_label"].tolist()
        self.tokenizer = tokenizer
        self.max_len = max_len

    def __len__(self):
        return len(self.texts)

    def __getitem__(self, idx):
        encoding = self.tokenizer(
            self.texts[idx],
            truncation=True,
            padding="max_length",
            max_length=self.max_len,
            return_tensors="pt"
        )
        item = {k: v.squeeze(0) for k, v in encoding.items()}
        item["labels"] = torch.tensor(self.labels[idx], dtype=torch.long)
        return item

# -----------------------------
# Load model & tokenizer (EPOCH 2)
# -----------------------------
tokenizer = XLMRobertaTokenizer.from_pretrained(MODEL_PATH)
model = XLMRobertaForSequenceClassification.from_pretrained(MODEL_PATH)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device)
model.eval()

# -----------------------------
# DataLoader
# -----------------------------
test_loader = DataLoader(
    NewsDataset(test_df, tokenizer),
    batch_size=32
)

# -----------------------------
# Evaluation
# -----------------------------
all_preds = []
all_labels = []

with torch.no_grad():
    for batch in test_loader:
        batch = {k: v.to(device) for k, v in batch.items()}
        outputs = model(**batch)
        preds = torch.argmax(outputs.logits, dim=1)

        all_preds.extend(preds.cpu().numpy())
        all_labels.extend(batch["labels"].cpu().numpy())

# -----------------------------
# Metrics
# -----------------------------
from sklearn.metrics import (
    accuracy_score,
    precision_recall_fscore_support,
    confusion_matrix,
    classification_report,
    roc_auc_score
)
import numpy as np

# -----------------------------
# BASIC METRICS
# -----------------------------
acc = accuracy_score(all_labels, all_preds)

# Weighted (dataset-aware)
p_w, r_w, f1_w, _ = precision_recall_fscore_support(
    all_labels, all_preds, average="weighted"
)

# Macro (class-fair)
p_m, r_m, f1_m, _ = precision_recall_fscore_support(
    all_labels, all_preds, average="macro"
)

# Class-wise
p_c, r_c, f1_c, _ = precision_recall_fscore_support(
    all_labels, all_preds, average=None
)

# Confusion Matrix
cm = confusion_matrix(all_labels, all_preds)

# ROC-AUC
roc_auc = roc_auc_score(all_labels, all_preds)

# -----------------------------
# DISPLAY RESULTS
# -----------------------------
print("\n" + "="*55)
print("        TEXT-ONLY MODEL - TEST RESULTS")
print("="*55)

print(f"Accuracy              : {acc:.4f}")
print(f"ROC-AUC               : {roc_auc:.4f}")

print("\n--- Weighted Average ---\n")
print(f"Precision (W)         : {p_w:.4f}")
print(f"Recall (W)            : {r_w:.4f}")
print(f"F1-score (W)          : {f1_w:.4f}")

print("\n--- Macro Average ---\n")
print(f"Precision (M)         : {p_m:.4f}")
print(f"Recall (M)            : {r_m:.4f}")
print(f"F1-score (M)          : {f1_m:.4f}")

print("\n--- Class-wise Metrics ---")
print("\nClass 0 (REAL):\n")
print(f"  Precision           : {p_c[0]:.4f}")
print(f"  Recall              : {r_c[0]:.4f}")
print(f"  F1-score            : {f1_c[0]:.4f}")

print("\nClass 1 (FAKE):\n")
print(f"  Precision           : {p_c[1]:.4f}")
print(f"  Recall              : {r_c[1]:.4f}")
print(f"  F1-score            : {f1_c[1]:.4f}")

print("\n--- Confusion Matrix ---\n")
print("          Pred REAL   Pred FAKE\n")
print(f"Actual REAL    {cm[0][0]:5d}       {cm[0][1]:5d}")
print(f"Actual FAKE    {cm[1][0]:5d}       {cm[1][1]:5d}")

print("\nDetailed Classification Report:\n")
print(classification_report(all_labels, all_preds, target_names=["REAL", "FAKE"]))
