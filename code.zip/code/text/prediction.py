import pandas as pd
import torch
import random
import numpy as np
from transformers import XLMRobertaTokenizer, XLMRobertaForSequenceClassification

# ================= CONFIG =================
DATA_PATH = r"C:\Users\Janvi\OneDrive\Desktop\Sem_8_Project\dataset\fakeddit\tsv\test_standardized.tsv"
MODEL_PATH = r"C:\Users\Janvi\OneDrive\Desktop\Sem_8_Project\checkpoints\epoch_2"

LABEL_MAP = {0: "REAL", 1: "FAKE"}
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# ================= LOAD DATA =================
df = pd.read_csv(DATA_PATH, sep="\t")
row = df.sample(1).iloc[0]

text = str(row["clean_title"])
actual_label = int(row["2_way_label"])

# ================= LOAD MODEL =================
tokenizer = XLMRobertaTokenizer.from_pretrained("xlm-roberta-base")
model = XLMRobertaForSequenceClassification.from_pretrained(MODEL_PATH)
model.to(DEVICE)
model.eval()

# ================= PREDICTION FUNCTION =================
def predict_confidence(text):
    inputs = tokenizer(
        text,
        return_tensors="pt",
        truncation=True,
        max_length=128
    ).to(DEVICE)

    with torch.no_grad():
        outputs = model(**inputs)

    probs = torch.softmax(outputs.logits, dim=1)[0]
    pred = torch.argmax(probs).item()
    return pred, probs[pred].item()

# ================= BASE PREDICTION =================
pred_label, base_conf = predict_confidence(text)

result = "CORRECT " if pred_label == actual_label else "INCORRECT "

print("===============================================================================================")
print("\n           RANDOM TEST SAMPLE\n")
print(text)
print("\n===============================================================================================")

print("\n           PREDICTION RESULT \n")
print(f"Actual Label    : {LABEL_MAP[actual_label]}")
print(f"Predicted Label : {LABEL_MAP[pred_label]}")
print(f"Confidence      : {base_conf:.4f}")
print(f"Result          : {result}")
print("\n===============================================================================================")

# ================= EXPLAINABILITY (PERTURBATION) =================
words = text.split()
importance_scores = []

for i, word in enumerate(words):
    perturbed_text = " ".join(words[:i] + words[i+1:])
    _, perturbed_conf = predict_confidence(perturbed_text)
    importance = base_conf - perturbed_conf
    importance_scores.append((word, importance))

# Sort by importance
importance_scores = sorted(
    importance_scores,
    key=lambda x: x[1],
    reverse=True
)
print("\n           IMPORTANT WORDS (PERTURBATION EXPLANATION)\n")
for word, score in importance_scores[:10]:
    if score > 0:
        print(f"{word:<12} -> importance {score:.3f}")
print("\n===============================================================================================")
