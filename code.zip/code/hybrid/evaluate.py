import torch
import pandas as pd
import numpy as np
from PIL import Image
from tqdm import tqdm

from torch.utils.data import Dataset, DataLoader
from transformers import XLMRobertaTokenizer
from torchvision import transforms

from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    classification_report,
    balanced_accuracy_score
)

from model import MultimodalFakeNewsModel

# =====================================================
# CONFIG
# =====================================================
TEST_FILE = r"C:\Users\Janvi\OneDrive\Desktop\Sem_8_Project\dataset\Fakeddit\tsv\test_hybrid.tsv"
MODEL_PATH = "checkpoints/hybrid_model/best_hybrid_model.pth"

MODEL_NAME = "xlm-roberta-base"
MAX_LEN = 128
BATCH_SIZE = 4

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# =====================================================
# TOKENIZER & TRANSFORMS
# =====================================================
tokenizer = XLMRobertaTokenizer.from_pretrained(MODEL_NAME)

image_transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize(
        mean=[0.485, 0.456, 0.406],
        std=[0.229, 0.224, 0.225]
    )
])

# =====================================================
# DATASET
# =====================================================
class HybridDataset(Dataset):
    def __init__(self, tsv_file):
        self.df = pd.read_csv(tsv_file, sep="\t")

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]

        encoding = tokenizer(
            str(row["text_multilingual"]),
            truncation=True,
            max_length=MAX_LEN,
            padding="max_length",
            return_tensors="pt"
        )

        image = Image.open(row["image_path"]).convert("RGB")
        image = image_transform(image)

        return {
            "input_ids": encoding["input_ids"].squeeze(0),
            "attention_mask": encoding["attention_mask"].squeeze(0),
            "image": image,
            "label": torch.tensor(row["2_way_label"], dtype=torch.long)
        }

# =====================================================
# LOAD DATA
# =====================================================
test_loader = DataLoader(
    HybridDataset(TEST_FILE),
    batch_size=BATCH_SIZE,
    shuffle=False
)

# =====================================================
# LOAD MODEL
# =====================================================
model = MultimodalFakeNewsModel(MODEL_NAME).to(DEVICE)
model.load_state_dict(torch.load(MODEL_PATH, map_location=DEVICE))
model.eval()

# =====================================================
# EVALUATION
# =====================================================
all_preds = []
all_labels = []

with torch.no_grad():
    for batch in tqdm(test_loader, desc="Evaluating"):
        outputs = model(
            input_ids=batch["input_ids"].to(DEVICE),
            attention_mask=batch["attention_mask"].to(DEVICE),
            images=batch["image"].to(DEVICE)
        )

        logits = outputs["logits"]
        preds = torch.argmax(logits, dim=1)

        all_preds.extend(preds.cpu().numpy())
        all_labels.extend(batch["label"].numpy())

# =====================================================
# METRICS
# =====================================================
acc = accuracy_score(all_labels, all_preds)
prec = precision_score(all_labels, all_preds)
rec = recall_score(all_labels, all_preds)
f1 = f1_score(all_labels, all_preds)
bal_acc = balanced_accuracy_score(all_labels, all_preds)

cm = confusion_matrix(all_labels, all_preds)
report = classification_report(all_labels, all_preds, target_names=["Real", "Fake"])

# =====================================================
# PRINT RESULTS
# =====================================================
print("\n========== FINAL HYBRID MODEL RESULTS ==========\n")

print(f"Accuracy            : {acc:.4f}")
print(f"Balanced Accuracy   : {bal_acc:.4f}")
print(f"Precision           : {prec:.4f}")
print(f"Recall              : {rec:.4f}")
print(f"F1-score            : {f1:.4f}")

print("\nConfusion Matrix:")
print(cm)

print("\nClass-wise Report:")
print(report)

print("==============================================\n")
