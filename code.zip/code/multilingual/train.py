import os
import torch
import torch.nn as nn
import pandas as pd
import numpy as np

from transformers import (
    XLMRobertaTokenizer,
    XLMRobertaModel,
    Trainer,
    TrainingArguments,
    DataCollatorWithPadding
)

from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

# =====================================================
# CONFIG
# =====================================================
BASE_PATH = r"C:\Users\Janvi\OneDrive\Desktop\Sem_8_Project\dataset\Fakeddit\tsv"

TRAIN_FILE = os.path.join(BASE_PATH, "train_multilingual.tsv")
VAL_FILE   = os.path.join(BASE_PATH, "val_multilingual.tsv")
TEST_FILE  = os.path.join(BASE_PATH, "test_multilingual.tsv")

MODEL_NAME = "xlm-roberta-base"
OUTPUT_DIR = "checkpoints/text_multilingual_advanced"

MAX_LEN = 128
BATCH_SIZE = 8        
EPOCHS = 2
LR = 2e-5

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

# =====================================================
# LOAD DATA
# =====================================================
train_df = pd.read_csv(TRAIN_FILE, sep="\t")
val_df   = pd.read_csv(VAL_FILE, sep="\t")
test_df  = pd.read_csv(TEST_FILE, sep="\t")

# =====================================================
# TOKENIZER
# =====================================================
tokenizer = XLMRobertaTokenizer.from_pretrained(MODEL_NAME)

# =====================================================
# DATASET
# =====================================================
class NewsDataset(torch.utils.data.Dataset):
    def __init__(self, df):
        self.texts = df["text_multilingual"].astype(str).tolist()
        self.labels = df["2_way_label"].tolist()

    def __len__(self):
        return len(self.texts)

    def __getitem__(self, idx):
        encoding = tokenizer(
            self.texts[idx],
            truncation=True,
            max_length=MAX_LEN
        )
        encoding["labels"] = self.labels[idx]
        return encoding

train_dataset = NewsDataset(train_df)
val_dataset   = NewsDataset(val_df)
test_dataset  = NewsDataset(test_df)

# =====================================================
# ADVANCED MULTILINGUAL MODEL
# =====================================================
class AdvancedMultilingualXLMR(nn.Module):
    def __init__(self, model_name, num_labels=2):
        super().__init__()

        self.encoder = XLMRobertaModel.from_pretrained(model_name)
        hidden = self.encoder.config.hidden_size

        self.classifier = nn.Sequential(
            nn.Linear(hidden * 2, hidden),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(hidden, num_labels)
        )

    def forward(self, input_ids, attention_mask, labels=None):
        outputs = self.encoder(
            input_ids=input_ids,
            attention_mask=attention_mask
        )

        last_hidden = outputs.last_hidden_state

        # CLS pooling
        cls_token = last_hidden[:, 0]

        # Mean pooling (masked)
        mask = attention_mask.unsqueeze(-1).float()
        mean_pool = (last_hidden * mask).sum(1) / mask.sum(1)

        fused = torch.cat([cls_token, mean_pool], dim=1)
        logits = self.classifier(fused)

        loss = None
        if labels is not None:
            loss_fn = nn.CrossEntropyLoss()
            loss = loss_fn(logits, labels)

        return {"loss": loss, "logits": logits}

model = AdvancedMultilingualXLMR(MODEL_NAME).to(DEVICE)

# =====================================================
# METRICS
# =====================================================
def compute_metrics(eval_pred):
    logits, labels = eval_pred
    preds = np.argmax(logits, axis=1)

    return {
        "accuracy": accuracy_score(labels, preds),
        "precision": precision_score(labels, preds),
        "recall": recall_score(labels, preds),
        "f1": f1_score(labels, preds)
    }

# =====================================================
# TRAINING ARGUMENTS (PAPER SAFE)
# =====================================================
training_args = TrainingArguments(
    output_dir=OUTPUT_DIR,
    eval_strategy="epoch",   
    save_strategy="no",
    learning_rate=LR,
    per_device_train_batch_size=BATCH_SIZE,
    per_device_eval_batch_size=BATCH_SIZE,
    num_train_epochs=EPOCHS,
    weight_decay=0.01,
    warmup_ratio=0.1,
    logging_strategy="epoch",      
    fp16=torch.cuda.is_available(),
    report_to="none",
    disable_tqdm=False             
)

# =====================================================
# TRAINER
# =====================================================
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=train_dataset,
    eval_dataset=val_dataset,
    tokenizer=tokenizer,
    data_collator=DataCollatorWithPadding(tokenizer),
    compute_metrics=compute_metrics
)

# =====================================================
# TRAIN
# =====================================================
trainer.train()

# =====================================================
# TEST
# =====================================================
test_results = trainer.evaluate(test_dataset)

print("\n================ FINAL TEST RESULTS ================\n")

print(f"Accuracy  : {test_results['eval_accuracy']:.4f}")
print(f"Precision : {test_results['eval_precision']:.4f}")
print(f"Recall    : {test_results['eval_recall']:.4f}")
print(f"F1-score  : {test_results['eval_f1']:.4f}")
print(f"Loss      : {test_results['eval_loss']:.4f}")

print("\n====================================================\n")


# =====================================================
# SAVE MODEL
# =====================================================
os.makedirs(OUTPUT_DIR, exist_ok=True)

model.encoder.save_pretrained(OUTPUT_DIR)
tokenizer.save_pretrained(OUTPUT_DIR)

print("\nAdvanced multilingual text model saved successfully.")
