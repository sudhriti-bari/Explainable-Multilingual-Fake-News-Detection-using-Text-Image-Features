import os
import random
import torch
import pandas as pd
import numpy as np

from transformers import (
    RobertaTokenizerFast,
    RobertaForSequenceClassification
)
from lime.lime_text import LimeTextExplainer

# ================= CONFIG =================
MODEL_PATH = r"C:\Users\Janvi\OneDrive\Desktop\Sem_8_Project\checkpoints\english_epoch_2"
TSV_PATH   = r"C:\Users\Janvi\OneDrive\Desktop\Sem_8_Project\dataset\fakeddit\tsv\val_standardized.tsv"
OUTPUT_DIR = "english_lime_html_outputs"

NUM_SAMPLES = 5
MAX_LEN = 128
CLASS_NAMES = ["REAL", "FAKE"]

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
os.makedirs(OUTPUT_DIR, exist_ok=True)

# ================= LOAD MODEL & TOKENIZER =================
tokenizer = RobertaTokenizerFast.from_pretrained(MODEL_PATH)
model = RobertaForSequenceClassification.from_pretrained(MODEL_PATH)

model.to(DEVICE)
model.eval()

print("English model & tokenizer loaded successfully")

# ================= LOAD DATA =================
df = pd.read_csv(TSV_PATH, sep="\t")

# ---- SAFE TEXT CONSTRUCTION ----
df["final_text"] = (
    df["clean_title"].fillna("") + " " +
    df["clean_text"].fillna("")
)

texts  = df["final_text"].tolist()
labels = df["2_way_label"].tolist()

# ================= PREDICTION FUNCTION =================
def predict_proba(text_list):
    enc = tokenizer(
        text_list,
        padding=True,
        truncation=True,
        max_length=MAX_LEN,
        return_tensors="pt"
    )
    enc = {k: v.to(DEVICE) for k, v in enc.items()}

    with torch.no_grad():
        outputs = model(**enc)
        probs = torch.softmax(outputs.logits, dim=1)

    return probs.cpu().numpy()

# ================= LIME EXPLAINER =================
explainer = LimeTextExplainer(
    class_names=CLASS_NAMES,
    split_expression=r"\W+"
)

# ================= RUN EXPLANATIONS =================
sample_indices = random.sample(range(len(texts)), NUM_SAMPLES)

for i, idx in enumerate(sample_indices, 1):

    text = texts[idx]
    true_label = CLASS_NAMES[labels[idx]]

    probs = predict_proba([text])[0]
    pred_idx = int(np.argmax(probs))
    pred_label = CLASS_NAMES[pred_idx]

    print("=" * 80)
    print(f"Sample {i}")
    print(f"ACTUAL LABEL    : {true_label}")
    print(f"PREDICTED LABEL : {pred_label}")
    print(f"PROBABILITIES  : \nReal={probs[0]:.4f}  ,  Fake={probs[1]:.4f}")
    print("Top influential words:")

    explanation = explainer.explain_instance(
        text,
        predict_proba,
        num_features=10,
        labels=[pred_idx]
    )

    for word, weight in explanation.as_list(label=pred_idx):
        sign = "+" if weight > 0 else "-"
        print(f"{sign} {word} ({abs(weight):.3f})")

    # ================= SAVE HTML =================
    html_path = os.path.join(
        OUTPUT_DIR,
        f"sample_{i}_true_{true_label}_pred_{pred_label}.html"
    )

    explanation.save_to_file(html_path)
    print(f"HTML explanation saved to: {html_path}")

print("\nAll English HTML explanations generated successfully")
