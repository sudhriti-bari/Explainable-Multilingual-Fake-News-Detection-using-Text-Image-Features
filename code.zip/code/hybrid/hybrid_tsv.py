import pandas as pd
import os
from tqdm import tqdm

def build_hybrid(
    multilingual_tsv,
    image_tsv,
    output_tsv,
    image_base_dir=None
):
    print(f"\nBuilding hybrid from:")
    print(f"Text  : {multilingual_tsv}")
    print(f"Image : {image_tsv}")

    text_df = pd.read_csv(multilingual_tsv, sep="\t")
    img_df  = pd.read_csv(image_tsv, sep="\t")

    # Keep only needed columns
    text_df = text_df[
        ["clean_title", "text_multilingual", "language", "2_way_label"]
    ]
    img_df = img_df[
        ["clean_title", "image_path", "2_way_label"]
    ]

    # Inner join on clean_title
    hybrid_df = pd.merge(
        text_df,
        img_df,
        on=["clean_title", "2_way_label"],
        how="inner"
    )

    print(f"Matched samples before image check: {len(hybrid_df)}")

    # Validate image paths
    valid_rows = []

    for _, row in tqdm(hybrid_df.iterrows(), total=len(hybrid_df)):
        img_path = row["image_path"]

        if image_base_dir is not None:
            img_path = os.path.join(image_base_dir, img_path)

        if os.path.exists(img_path):
            row["image_path"] = img_path
            valid_rows.append(row)

    final_df = pd.DataFrame(valid_rows)

    print(f"Final valid samples: {len(final_df)}")

    final_df.to_csv(output_tsv, sep="\t", index=False)
    print(f"Saved hybrid TSV to {output_tsv}")

build_hybrid(
    multilingual_tsv=r"C:\Users\Janvi\OneDrive\Desktop\Sem_8_Project\dataset\Fakeddit\tsv\train_multilingual.tsv",
    image_tsv=r"C:\Users\Janvi\OneDrive\Desktop\Sem_8_Project\dataset\Fakeddit\tsv\train_final.tsv",
    output_tsv=r"C:\Users\Janvi\OneDrive\Desktop\Sem_8_Project\dataset\Fakeddit\tsv\train_hybrid.tsv"
)

build_hybrid(
    multilingual_tsv=r"C:\Users\Janvi\OneDrive\Desktop\Sem_8_Project\dataset\Fakeddit\tsv\val_multilingual.tsv",
    image_tsv=r"C:\Users\Janvi\OneDrive\Desktop\Sem_8_Project\dataset\Fakeddit\tsv\val_final.tsv",
    output_tsv=r"C:\Users\Janvi\OneDrive\Desktop\Sem_8_Project\dataset\Fakeddit\tsv\val_hybrid.tsv"
)

build_hybrid(
    multilingual_tsv=r"C:\Users\Janvi\OneDrive\Desktop\Sem_8_Project\dataset\Fakeddit\tsv\test_multilingual.tsv",
    image_tsv=r"C:\Users\Janvi\OneDrive\Desktop\Sem_8_Project\dataset\Fakeddit\tsv\image_test_balanced.tsv",
    output_tsv=r"C:\Users\Janvi\OneDrive\Desktop\Sem_8_Project\dataset\Fakeddit\tsv\test_hybrid.tsv"
)
