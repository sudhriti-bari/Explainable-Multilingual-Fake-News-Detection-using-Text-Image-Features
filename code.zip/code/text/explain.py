import torch
import pandas as pd
import random
from transformers import AutoTokenizer, AutoModelForSequenceClassification
from lime.lime_text import LimeTextExplainer

# ================= CONFIG ================= #
MODEL_PATH = r"checkpoints/epoch_2"   # BEST checkpoint
TEST_TSV = r"C:\Users\Janvi\OneDrive\Desktop\Sem_8_Project\dataset\fakeddit\tsv\test_standardized.tsv"
NUM_SAMPLES = 5
MAX_LEN = 128
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
CLASS_NAMES = ["REAL", "FAKE"]

# ================= LOAD MODEL & TOKENIZER ================= #
tokenizer = AutoTokenizer.from_pretrained(
    MODEL_PATH,
    use_fast=True
)

model = AutoModelForSequenceClassification.from_pretrained(MODEL_PATH)
model.to(DEVICE)
model.eval()

print("Model & tokenizer loaded successfully")

# ================= LOAD DATA ================= #
df = pd.read_csv(TEST_TSV, sep="\t")

texts = df["clean_title"].astype(str).tolist()
labels = df["2_way_label"].tolist()

# ================= FILTER MEANINGFUL TEXT ================= #
valid_indices = [
    i for i, t in enumerate(texts)
    if isinstance(t, str) and len(t.split()) >= 5
]

if len(valid_indices) < NUM_SAMPLES:
    raise ValueError("Not enough valid samples for explanation")

# ================= PRED FUNCTION FOR LIME ================= #
def predict_prob(text_list):
    enc = tokenizer(
        text_list,
        padding=True,
        truncation=True,
        max_length=MAX_LEN,
        return_tensors="pt"
    )
    enc = {k: v.to(DEVICE) for k, v in enc.items()}

    with torch.no_grad():
        outputs = model(**enc)
        probs = torch.softmax(outputs.logits, dim=1)

    return probs.cpu().numpy()

# ================= LIME EXPLAINER ================= #
explainer = LimeTextExplainer(class_names=CLASS_NAMES)

# ================= RANDOM SAMPLES ================= #
sample_indices = random.sample(valid_indices, NUM_SAMPLES)

# ================= EXPLAIN ================= #
for idx in sample_indices:
    text = texts[idx]
    true_label = CLASS_NAMES[labels[idx]]

    print("=" * 90)
    print("ORIGINAL TEXT:\n")
    print(text)

    exp = explainer.explain_instance(
        text,
        predict_prob,
        num_features=10
    )

    pred_idx = predict_prob([text]).argmax()

    print("\nACTUAL LABEL   :", true_label)
    print("PREDICTED LABEL:", CLASS_NAMES[pred_idx])

    print("\nTOP INFLUENTIAL WORDS (LIME):")
    for word, weight in exp.as_list():
        sign = "+" if weight > 0 else "-"
        print(f"{sign} {word} ({weight:.4f})")

    print("=" * 90 + "\n")
