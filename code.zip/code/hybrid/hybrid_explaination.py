import os
import torch
import torch.nn as nn
import pandas as pd
import numpy as np
from PIL import Image
from torchvision import models, transforms
from transformers import XLMRobertaTokenizer, XLMRobertaModel
import cv2, base64
from io import BytesIO

# ================= CONFIG =================
BASE_PATH = r"C:\Users\Janvi\OneDrive\Desktop\Sem_8_Project\dataset\Fakeddit\tsv"
TEST_FILE = os.path.join(BASE_PATH, "test_hybrid.tsv")
MODEL_PATH = r"checkpoints\hybrid_model\best_hybrid_model.pth"

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
NUM_SAMPLES = 3
MAX_LEN = 128
TOP_K = 10   # number of important words

# ================= TOKENIZER =================
tokenizer = XLMRobertaTokenizer.from_pretrained("xlm-roberta-base")

# ================= IMAGE TRANSFORM =================
img_transform = transforms.Compose([
    transforms.Resize((224,224)),
    transforms.ToTensor(),
    transforms.Normalize([0.485,0.456,0.406],[0.229,0.224,0.225])
])

# ================= MODEL =================
class AdvancedHybridFakeNewsModel(nn.Module):
    def __init__(self):
        super().__init__()

        self.text_encoder = XLMRobertaModel.from_pretrained(
            "xlm-roberta-base",
            output_attentions=True
        )

        self.image_encoder = models.resnet50(
            weights=models.ResNet50_Weights.IMAGENET1K_V1
        )
        self.image_encoder.fc = nn.Identity()

        self.text_proj = nn.Linear(768, 768)
        self.image_proj = nn.Linear(2048, 768)

        self.gate = nn.Sequential(
            nn.Linear(1536, 768),
            nn.Sigmoid()
        )

        self.classifier = nn.Sequential(
            nn.Linear(768, 512),
            nn.ReLU(),
            nn.Linear(512, 2)
        )

    def forward(self, ids, mask, image):
        text_out = self.text_encoder(
            ids,
            attention_mask=mask,
            output_attentions=True
        )

        text_feat = self.text_proj(text_out.last_hidden_state[:, 0])
        img_feat = self.image_proj(self.image_encoder(image))

        combined = torch.cat([text_feat, img_feat], dim=1)
        gate = self.gate(combined)

        fused = gate * text_feat + (1 - gate) * img_feat
        logits = self.classifier(fused)

        return logits, text_out.attentions, gate.mean(dim=1)

# ================= LOAD MODEL =================
model = AdvancedHybridFakeNewsModel().to(DEVICE)
model.load_state_dict(torch.load(MODEL_PATH, map_location=DEVICE), strict=False)
model.eval()
model.image_encoder.requires_grad_(True)

# ================= GRAD-CAM =================
activations, gradients = [], []

def fwd_hook(_,__,out): activations.append(out)
def bwd_hook(_,gi,go): gradients.append(go[0])

target_layer = model.image_encoder.layer3[-1]
target_layer.register_forward_hook(fwd_hook)
target_layer.register_full_backward_hook(bwd_hook)

# ================= DATA =================
df = pd.read_csv(TEST_FILE, sep="\t")
samples = df.sample(NUM_SAMPLES)

# ================= HTML =================
html = """
<html><head>
<style>
body{font-family:Arial;background:#111;color:#eee}
.card{padding:18px;margin:20px;border-radius:12px}
.good{border:2px solid #00ff99}
.bad{border:2px solid #ff4444}
.word{padding:4px;margin:3px;border-radius:6px;display:inline-block}
img{border-radius:10px;margin:8px}
h2{margin-bottom:6px}
</style></head><body>
<h1>Hybrid Fake News Explainability</h1>
"""

def img_to_html(img):
    buf = BytesIO()
    img.save(buf, format="PNG")
    return base64.b64encode(buf.getvalue()).decode()

# ================= PROCESS =================
for _, row in samples.iterrows():

    text = str(row["text_multilingual"])
    true = int(row["2_way_label"])
    img_path = row["image_path"]

    enc = tokenizer(text, return_tensors="pt", truncation=True, max_length=MAX_LEN)
    ids, mask = enc["input_ids"].to(DEVICE), enc["attention_mask"].to(DEVICE)

    raw_img = Image.open(img_path).convert("RGB")
    img_tensor = img_transform(raw_img).unsqueeze(0).to(DEVICE)

    activations.clear(); gradients.clear()

    logits, attn, gate = model(ids, mask, img_tensor)
    pred = logits.argmax(dim=1).item()

    correct = (pred == true)
    box_class = "good" if correct else "bad"
    color = "#00ff99" if correct else "#ff4444"

    # -------- TEXT ATTENTION --------
    attn_scores = torch.stack(attn[-4:]).mean(dim=0).mean(dim=1)[0].mean(dim=0)
    tokens = tokenizer.convert_ids_to_tokens(ids[0])

    token_scores = [
        ((t.replace("▁",""), s.detach().item()))
        for t,s in zip(tokens, attn_scores)
        if t not in ["<s>","</s>","<pad>"]
    ]

    top_tokens = sorted(token_scores, key=lambda x: x[1], reverse=True)[:TOP_K]

    imp_html = ""
    for w,s in top_tokens:
        imp_html += f"<span class='word' style='background:{color}'>{w}</span> "

    # -------- GRAD-CAM --------
    model.zero_grad()
    logits[0,pred].backward()

    grad = gradients[0].mean(dim=[1,2])
    act = activations[0][0]

    cam = torch.zeros(act.shape[1:], device=DEVICE)
    for i,w in enumerate(grad):
        cam += w * act[i]

    cam = torch.relu(cam)

    if torch.max(cam) != 0:
        cam = cam / torch.max(cam)

    cam = cam.detach().cpu().numpy()

    cam = cv2.resize(cam, raw_img.size)
    heatmap = Image.fromarray(cv2.applyColorMap(np.uint8(255*cam), cv2.COLORMAP_JET))
    overlay = Image.blend(raw_img, heatmap, 0.35)

    # -------- CONTRIBUTION --------
    text_pct = gate.item()*100
    img_pct = 100 - text_pct

    html += f"""
    <div class="card {box_class}">
    <h2 style="color:{color}">
    Prediction: {"FAKE" if pred else "REAL"} |
    Actual: {"FAKE" if true else "REAL"}
    </h2>

    <p><b>Text Contribution:</b> {text_pct:.1f}% |
       <b>Image Contribution:</b> {img_pct:.1f}%</p>

    <h3>Original Multilingual Text</h3>
    <p>{text}</p>

    <h3>Important Words Influencing Decision</h3>
    {imp_html}

    <h3>Image Explanation</h3>
    <img src="data:image/png;base64,{img_to_html(raw_img)}" width="260">
    <img src="data:image/png;base64,{img_to_html(overlay)}" width="260">
    </div>
    """

html += "</body></html>"

with open("hybrid_explanation.html","w",encoding="utf-8") as f:
    f.write(html)

print("Explainability report generated: hybrid_explanation.html")
