import os
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from torchvision import models, transforms
from tqdm import tqdm
import pandas as pd
from PIL import Image

# =====================================================
# CONFIG
# =====================================================
BASE_DATASET = r"C:\Users\Janvi\OneDrive\Desktop\Sem_8_Project\dataset\Fakeddit\tsv"

TRAIN_TSV = os.path.join(BASE_DATASET, "image_train_balanced.tsv")
VAL_TSV   = os.path.join(BASE_DATASET, "image_val_balanced.tsv")

OUTPUT_DIR = "checkpoints/image_resnet"
os.makedirs(OUTPUT_DIR, exist_ok=True)

BATCH_SIZE = 32
EPOCHS_PHASE1 = 2
EPOCHS_PHASE2 = 3

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# =====================================================
# DATASET
# =====================================================
class ImageDataset(torch.utils.data.Dataset):
    def __init__(self, tsv_path, transform=None):
        self.data = pd.read_csv(tsv_path, sep="\t")
        self.transform = transform

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        img_path = self.data.iloc[idx]["image_path"]
        label = int(self.data.iloc[idx]["2_way_label"])

        image = Image.open(img_path).convert("RGB")
        if self.transform:
            image = self.transform(image)

        return image, label

# =====================================================
# TRANSFORMS (NO OVER-AUGMENTATION)
# =====================================================
transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize(
        mean=[0.485, 0.456, 0.406],
        std=[0.229, 0.224, 0.225]
    )
])

train_dataset = ImageDataset(TRAIN_TSV, transform)
val_dataset   = ImageDataset(VAL_TSV, transform)

train_loader = DataLoader(
    train_dataset,
    batch_size=32,
    shuffle=True,
    num_workers=0
)

val_loader = DataLoader(
    val_dataset,
    batch_size=32,
    shuffle=False,
    num_workers=0
)


# =====================================================
# MODEL — RESNET-50
# =====================================================
model = models.resnet50(pretrained=True)

# Freeze backbone
for param in model.parameters():
    param.requires_grad = False

# Replace classifier
model.fc = nn.Linear(model.fc.in_features, 2)
model = model.to(DEVICE)

criterion = nn.CrossEntropyLoss()

# =====================================================
# PHASE 1 — FEATURE EXTRACTION
# =====================================================
optimizer = torch.optim.Adam(model.fc.parameters(), lr=1e-3)

print("\nPHASE 1: Feature Extraction\n")

for epoch in range(EPOCHS_PHASE1):
    model.train()
    running_loss = 0

    for images, labels in tqdm(train_loader, desc=f"Epoch {epoch+1}/{EPOCHS_PHASE1}"):
        images, labels = images.to(DEVICE), labels.to(DEVICE)

        optimizer.zero_grad()
        outputs = model(images)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()

        running_loss += loss.item()

    print(f"Train Loss: {running_loss / len(train_loader):.4f}")

# =====================================================
# PHASE 2 — LIGHT FINE-TUNING (LAST BLOCK ONLY)
# =====================================================
for name, param in model.named_parameters():
    if "layer4" in name:
        param.requires_grad = True

optimizer = torch.optim.Adam(
    filter(lambda p: p.requires_grad, model.parameters()),
    lr=1e-4
)

print("\nPHASE 2: Fine-Tuning (Last Block)\n")

for epoch in range(EPOCHS_PHASE2):
    model.train()
    running_loss = 0

    for images, labels in tqdm(train_loader, desc=f"FineTune {epoch+1}/{EPOCHS_PHASE2}"):
        images, labels = images.to(DEVICE), labels.to(DEVICE)

        optimizer.zero_grad()
        outputs = model(images)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()

        running_loss += loss.item()

    print(f"Train Loss: {running_loss / len(train_loader):.4f}")

# =====================================================
# SAVE MODEL
# =====================================================
torch.save(model.state_dict(), os.path.join(OUTPUT_DIR, "resnet50_image.pth"))
print("\nResNet-50 image model saved successfully")
