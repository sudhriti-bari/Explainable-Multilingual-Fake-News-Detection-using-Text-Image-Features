import torch
import torch.nn as nn
import pandas as pd
import numpy as np
from transformers import XLMRobertaTokenizer, XLMRobertaModel
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, classification_report, confusion_matrix

# -----------------------------
# CONFIG
# -----------------------------
MODEL_DIR = "checkpoints/text_multilingual_advanced"
TEST_FILE = r"C:\Users\Janvi\OneDrive\Desktop\Sem_8_Project\dataset\Fakeddit\tsv\test_multilingual.tsv"

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
MAX_LEN = 128

# -----------------------------
# MODEL DEFINITION (SAME AS TRAINING)
# -----------------------------
class AdvancedMultilingualXLMR(nn.Module):
    def __init__(self, model_dir, num_labels=2):
        super().__init__()
        self.encoder = XLMRobertaModel.from_pretrained(model_dir)
        hidden = self.encoder.config.hidden_size

        self.classifier = nn.Sequential(
            nn.Linear(hidden * 2, hidden),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(hidden, num_labels)
        )

    def forward(self, input_ids, attention_mask):
        outputs = self.encoder(input_ids=input_ids, attention_mask=attention_mask)
        last_hidden = outputs.last_hidden_state

        cls_token = last_hidden[:, 0]
        mask = attention_mask.unsqueeze(-1).float()
        mean_pool = (last_hidden * mask).sum(1) / mask.sum(1)

        fused = torch.cat([cls_token, mean_pool], dim=1)
        return self.classifier(fused)

# -----------------------------
# LOAD MODEL
# -----------------------------
tokenizer = XLMRobertaTokenizer.from_pretrained(MODEL_DIR)
model = AdvancedMultilingualXLMR(MODEL_DIR).to(DEVICE)
model.eval()

# -----------------------------
# LOAD DATA
# -----------------------------
df = pd.read_csv(TEST_FILE, sep="\t")

y_true, y_pred, confidences = [], [], []

# -----------------------------
# EVALUATION LOOP
# -----------------------------
for text, label in zip(df["text_multilingual"], df["2_way_label"]):
    inputs = tokenizer(
        text,
        return_tensors="pt",
        truncation=True,
        max_length=MAX_LEN
    ).to(DEVICE)

    with torch.no_grad():
        logits = model(**inputs)

    probs = torch.softmax(logits, dim=1).cpu().numpy()[0]
    pred = np.argmax(probs)

    y_true.append(label)
    y_pred.append(pred)
    confidences.append(np.max(probs))

# -----------------------------
# METRICS
# -----------------------------
print("\n===== MULTILINGUAL TEST METRICS =====\n")
print("Accuracy :", accuracy_score(y_true, y_pred))
print("Precision:", precision_score(y_true, y_pred))
print("Recall   :", recall_score(y_true, y_pred))
print("F1-score :", f1_score(y_true, y_pred))

print("\n===== CLASSIFICATION REPORT =====\n")
print(classification_report(y_true, y_pred, target_names=["Real", "Fake"]))

print("\n===== CONFUSION MATRIX =====\n")
print(confusion_matrix(y_true, y_pred))

print("\nAverage Prediction Confidence:", np.mean(confidences))
