import torch
import torch.nn as nn
from transformers import XLMRobertaModel
from torchvision import models

# =====================================================
# MULTIMODAL HYBRID MODEL WITH CROSS-MODAL ATTENTION
# =====================================================
class MultimodalFakeNewsModel(nn.Module):
    def __init__(self, text_model_name="xlm-roberta-base", num_labels=2):
        super().__init__()

        # -------------------------------
        # TEXT ENCODER (XLM-R)
        # -------------------------------
        self.text_encoder = XLMRobertaModel.from_pretrained(text_model_name)
        text_hidden = self.text_encoder.config.hidden_size  # 768

        # Freeze lower layers (prevents overfitting)
        for name, param in self.text_encoder.named_parameters():
            if "layer.10" not in name and "layer.11" not in name:
                param.requires_grad = False

        # -------------------------------
        # IMAGE ENCODER (ResNet-50)
        # -------------------------------
        self.image_encoder = models.resnet50(pretrained=True)
        image_hidden = self.image_encoder.fc.in_features  # 2048
        self.image_encoder.fc = nn.Identity()

        for param in self.image_encoder.parameters():
            param.requires_grad = False

        # -------------------------------
        # PROJECTION TO SHARED SPACE
        # -------------------------------
        self.text_proj = nn.Linear(text_hidden, 768)
        self.image_proj = nn.Linear(image_hidden, 768)

        # -------------------------------
        # CROSS-MODAL ATTENTION
        # -------------------------------
        self.cross_attention = nn.MultiheadAttention(
            embed_dim=768,
            num_heads=8,
            dropout=0.2,
            batch_first=True
        )

        # -------------------------------
        # GATED FUSION
        # -------------------------------
        self.gate = nn.Sequential(
            nn.Linear(768 * 2, 768),
            nn.Sigmoid()
        )

        # -------------------------------
        # CLASSIFIER
        # -------------------------------
        self.classifier = nn.Sequential(
            nn.Linear(768, 512),
            nn.ReLU(),
            nn.Dropout(0.4),
            nn.Linear(512, num_labels)
        )

    # =====================================================
    # FORWARD
    # =====================================================
    def forward(self, input_ids, attention_mask, images, labels=None):
        # -------- TEXT --------
        text_out = self.text_encoder(
            input_ids=input_ids,
            attention_mask=attention_mask
        )
        text_cls = text_out.last_hidden_state[:, 0]  # CLS token
        text_feat = self.text_proj(text_cls)

        # -------- IMAGE --------
        image_feat = self.image_encoder(images)
        image_feat = self.image_proj(image_feat)

        # -------- CROSS-MODAL ATTENTION --------
        text_feat_att, attn_weights = self.cross_attention(
            query=text_feat.unsqueeze(1),
            key=image_feat.unsqueeze(1),
            value=image_feat.unsqueeze(1)
        )

        text_feat_att = text_feat_att.squeeze(1)

        # -------- GATED FUSION --------
        fusion_input = torch.cat([text_feat_att, image_feat], dim=1)
        gate = self.gate(fusion_input)

        fused = gate * text_feat_att + (1 - gate) * image_feat

        # -------- CLASSIFICATION --------
        logits = self.classifier(fused)

        loss = None
        if labels is not None:
            loss_fn = nn.CrossEntropyLoss()
            loss = loss_fn(logits, labels)

        return {
            "loss": loss,
            "logits": logits,
            "attn_weights": attn_weights,
            "fusion_gate": gate
        }
