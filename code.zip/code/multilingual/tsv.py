import pandas as pd
import random
from deep_translator import GoogleTranslator
from tqdm import tqdm

# ================= CONFIG =================
BASE_TSV_PATH = r"C:\Users\Janvi\OneDrive\Desktop\Sem_8_Project\dataset\Fakeddit\tsv"

FILES = {
    "train": "train_standardized.tsv",
    "val":   "val_standardized.tsv",
    "test":  "test_standardized.tsv"
}

LANGUAGES = {
    "en": "english",
    "hi": "hindi",
    "gu": "gujarati",
    "es": "spanish"
}

# ================= TRANSLATION =================
def translate_text(text, lang_code):
    if lang_code == "en" or text.strip() == "":
        return text
    try:
        return GoogleTranslator(source="en", target=lang_code).translate(text)
    except:
        return text  # safe fallback

# ================= PROCESS =================
for split, file in FILES.items():
    df = pd.read_csv(f"{BASE_TSV_PATH}\\{file}", sep="\t")

    multilingual_texts = []
    languages_used = []

    print(f"\nProcessing {split} split...")

    for text in tqdm(df["clean_title"].astype(str).tolist()):
        lang = random.choice(list(LANGUAGES.keys()))
        translated = translate_text(text, lang)

        multilingual_texts.append(translated)
        languages_used.append(lang)

    df["text_multilingual"] = multilingual_texts
    df["language"] = languages_used

    out_file = f"{BASE_TSV_PATH}\\{split}_multilingual.tsv"
    df.to_csv(out_file, sep="\t", index=False)

    print(f"Saved to {out_file}")
