import os
import pandas as pd
import torch
from torch.utils.data import DataLoader, Dataset
from transformers import XLMRobertaTokenizer, XLMRobertaForSequenceClassification
from torch.optim import AdamW
from sklearn.metrics import accuracy_score, precision_recall_fscore_support
from tqdm import tqdm

# -----------------------------
# Paths
# -----------------------------
BASE_SAVE_PATH = r"C:\Users\Janvi\OneDrive\Desktop\Sem_8_Project\checkpoints"
BEST_MODEL_PATH = os.path.join(BASE_SAVE_PATH, "best_model")
os.makedirs(BASE_SAVE_PATH, exist_ok=True)

# -----------------------------
# Load datasets
# -----------------------------
train_df = pd.read_csv(
    r'C:\Users\Janvi\OneDrive\Desktop\Sem_8_Project\dataset\fakeddit\train_standardized.tsv',
    sep='\t'
)
val_df = pd.read_csv(
    r'C:\Users\Janvi\OneDrive\Desktop\Sem_8_Project\dataset\fakeddit\val_standardized.tsv',
    sep='\t'
)

print(f"Train: {len(train_df)} | Val: {len(val_df)}")

# -----------------------------
# Dataset class
# -----------------------------
class NewsDataset(Dataset):
    def __init__(self, df, tokenizer, max_len=128):
        self.texts = df['clean_title'].astype(str).tolist()
        self.labels = df['2_way_label'].tolist()
        self.tokenizer = tokenizer
        self.max_len = max_len

    def __len__(self):
        return len(self.texts)

    def __getitem__(self, idx):
        enc = self.tokenizer(
            self.texts[idx],
            truncation=True,
            padding='max_length',
            max_length=self.max_len,
            return_tensors='pt'
        )
        item = {k: v.squeeze(0) for k, v in enc.items()}
        item['labels'] = torch.tensor(self.labels[idx], dtype=torch.long)
        return item

# -----------------------------
# Device
# -----------------------------
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# -----------------------------
# Load model (resume safe)
# -----------------------------
if os.path.exists(BEST_MODEL_PATH):
    print("Loading existing checkpoint...")
    tokenizer = XLMRobertaTokenizer.from_pretrained(BEST_MODEL_PATH)
    model = XLMRobertaForSequenceClassification.from_pretrained(BEST_MODEL_PATH)
else:
    tokenizer = XLMRobertaTokenizer.from_pretrained("xlm-roberta-base")
    model = XLMRobertaForSequenceClassification.from_pretrained(
        "xlm-roberta-base",
        num_labels=2
    )

model.to(device)

# -----------------------------
# Dataloaders
# -----------------------------
batch_size = 32

train_loader = DataLoader(
    NewsDataset(train_df, tokenizer),
    batch_size=batch_size,
    shuffle=True
)

val_loader = DataLoader(
    NewsDataset(val_df, tokenizer),
    batch_size=batch_size
)

# -----------------------------
# Optimizer
# -----------------------------
optimizer = AdamW(model.parameters(), lr=2e-5)

# -----------------------------
# Training setup
# -----------------------------
epochs = 10
best_val_loss = float("inf")
patience = 2
patience_counter = 0

# -----------------------------
# Training loop (LIVE + AUTO SAVE)
# -----------------------------
for epoch in range(epochs):
    print(f"\n===== EPOCH {epoch+1} STARTED =====")
    model.train()
    total_loss = 0

    progress = tqdm(train_loader, desc=f"Training Epoch {epoch+1}", leave=True)

    for batch in progress:
        batch = {k: v.to(device) for k, v in batch.items()}
        outputs = model(**batch)
        loss = outputs.loss

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        total_loss += loss.item()
        progress.set_postfix(loss=loss.item())

    avg_train_loss = total_loss / len(train_loader)

    # -----------------------------
    # Validation
    # -----------------------------
    model.eval()
    val_loss = 0

    with torch.no_grad():
        for batch in val_loader:
            batch = {k: v.to(device) for k, v in batch.items()}
            val_loss += model(**batch).loss.item()

    avg_val_loss = val_loss / len(val_loader)

    print(f"\nEpoch {epoch+1} Finished")
    print(f"Train Loss: {avg_train_loss:.4f}")
    print(f"Val Loss  : {avg_val_loss:.4f}")

    # -----------------------------
    # Save checkpoint (EVERY EPOCH)
    # -----------------------------
    epoch_path = os.path.join(BASE_SAVE_PATH, f"epoch_{epoch+1}")
    model.save_pretrained(epoch_path)
    tokenizer.save_pretrained(epoch_path)
    print(f"Saved checkpoint: {epoch_path}")

    # -----------------------------
    # Best model saving
    # -----------------------------
    if avg_val_loss < best_val_loss:
        best_val_loss = avg_val_loss
        patience_counter = 0
        model.save_pretrained(BEST_MODEL_PATH)
        tokenizer.save_pretrained(BEST_MODEL_PATH)
        print("Best model updated")
    else:
        patience_counter += 1
        print(f"No improvement ({patience_counter}/{patience})")

    if patience_counter >= patience:
        print("Early stopping triggered")
        break

print("\nTraining completed safely")
