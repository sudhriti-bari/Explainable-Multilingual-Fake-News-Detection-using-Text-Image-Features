import os
import torch
import torch.nn.functional as F
import numpy as np
import pandas as pd
import cv2
import base64
from pathlib import Path
from PIL import Image
from torchvision import models, transforms
from transformers import AutoTokenizer, AutoModelForSequenceClassification

# ================= CONFIG =================
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

IMAGE_MODEL_PATH = r"C:\Users\Janvi\OneDrive\Desktop\Sem_8_Project\checkpoints\image_resnet\resnet50_image.pth"
TEXT_MODEL_PATH  = r"C:\Users\Janvi\OneDrive\Desktop\Sem_8_Project\checkpoints\text_multilingual_advanced"

DATA_FILE = r"C:\Users\Janvi\OneDrive\Desktop\Sem_8_Project\dataset\Fakeddit\tsv\test_hybrid.tsv"
OUTPUT_HTML = "decision_fusion_explainability_1.html"

NUM_SAMPLES = 5
MAX_LEN = 128
TOP_K_TOKENS = 12
CLASS_NAMES = ["REAL", "FAKE"]

# ================= LOAD DATA =================
df = pd.read_csv(DATA_FILE, sep="\t")
samples = df.sample(n=NUM_SAMPLES)

# ================= TEXT MODEL =================
tokenizer = AutoTokenizer.from_pretrained(TEXT_MODEL_PATH)
text_model = AutoModelForSequenceClassification.from_pretrained(TEXT_MODEL_PATH)
text_model.to(DEVICE).eval()

# ================= IMAGE MODEL =================
image_model = models.resnet50(pretrained=False)
image_model.fc = torch.nn.Linear(2048, 2)
image_model.load_state_dict(torch.load(IMAGE_MODEL_PATH, map_location=DEVICE))
image_model.to(DEVICE).eval()

# ================= IMAGE TRANSFORM =================
img_transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406],
                         [0.229, 0.224, 0.225])
])

# ================= GRAD-CAM SETUP =================
activations = []
gradients = []

def forward_hook(_, __, output):
    activations.append(output)

def backward_hook(_, grad_in, grad_out):
    gradients.append(grad_out[0])

target_layer = image_model.layer4[-1]
target_layer.register_forward_hook(forward_hook)
target_layer.register_full_backward_hook(backward_hook)

# ================= HTML =================
html = """
<html>
<head>
<style>
body { font-family: Arial; background:#0f172a; color:#e5e7eb; }
.card { background:#020617; margin:20px; padding:20px; border-radius:12px; }
.good { border-left:6px solid #22c55e; }
.bad { border-left:6px solid #ef4444; }
.word { padding:5px 8px; margin:4px; border-radius:6px; display:inline-block; }
.text-box { background:#020617; border:1px solid #334155; padding:12px; border-radius:8px; }
.row { display:flex; gap:20px; }
img { border-radius:10px; }
</style>
</head>
<body>

<h1>Decision Fusion Explainability Report</h1>
"""

# ================= PROCESS SAMPLES =================
for _, row in samples.iterrows():

    text = str(row["text_multilingual"])
    image_path = row["image_path"]
    true_label = int(row["2_way_label"])

    # ---------- TEXT ----------
    enc = tokenizer(text, return_tensors="pt",
                    truncation=True, max_length=MAX_LEN)
    enc = {k: v.to(DEVICE) for k, v in enc.items()}

    text_model.zero_grad()
    text_out = text_model(**enc)
    text_probs = F.softmax(text_out.logits, dim=1)
    text_pred = text_probs.argmax(dim=1).item()
    text_conf = text_probs[0, text_pred].item()

    text_out.logits[0, text_pred].backward()

    emb_grad = text_model.base_model.embeddings.word_embeddings.weight.grad
    token_ids = enc["input_ids"][0]
    tokens = tokenizer.convert_ids_to_tokens(token_ids)

    token_scores = emb_grad[token_ids].sum(dim=1).detach().cpu().numpy()
    token_scores = token_scores / (np.max(np.abs(token_scores)) + 1e-8)

    token_data = []
    for t, s in zip(tokens, token_scores):
        clean = t.replace("▁", "")
        if clean and clean not in ["<s>", "</s>", "<pad>"]:
            token_data.append((clean, s))

    token_data = sorted(token_data,
                        key=lambda x: abs(x[1]),
                        reverse=True)[:TOP_K_TOKENS]

    token_html = ""
    for w, s in token_data:
        color = "#22c55e" if s > 0 else "#ef4444"
        token_html += f"<span class='word' style='background:{color}'>{w}</span>"

    # ---------- IMAGE ----------
    activations.clear()
    gradients.clear()

    raw_img = Image.open(image_path).convert("RGB")
    img_tensor = img_transform(raw_img).unsqueeze(0).to(DEVICE)

    img_logits = image_model(img_tensor)
    img_probs = F.softmax(img_logits, dim=1)
    img_pred = img_probs.argmax(dim=1).item()
    img_conf = img_probs[0, img_pred].item()

    image_model.zero_grad()
    img_logits[0, img_pred].backward()

    grad = gradients[0].mean(dim=[1, 2])
    act = activations[0][0]

    cam = torch.zeros(act.shape[1:], device=DEVICE)
    for i, w in enumerate(grad):
        cam += w * act[i]

    cam = torch.relu(cam)
    cam = cam / (cam.max() + 1e-8)
    cam = cam.detach().cpu().numpy()

    cam = cv2.resize(cam, raw_img.size)
    heatmap = cv2.applyColorMap(np.uint8(255 * cam), cv2.COLORMAP_JET)
    overlay = cv2.addWeighted(np.array(raw_img), 0.6, heatmap, 0.4, 0)

    def img_to_html(img):
        _, buf = cv2.imencode(".png", cv2.cvtColor(img, cv2.COLOR_RGB2BGR))
        return base64.b64encode(buf).decode()

    # ---------- FINAL DECISION ----------
    final_pred = text_pred if text_conf >= img_conf else img_pred
    box_class = "good" if final_pred == true_label else "bad"

    html += f"""
    <div class="card {box_class}">
    <h2>Prediction: {CLASS_NAMES[final_pred]} | Actual: {CLASS_NAMES[true_label]}</h2>

    <p>Text confidence: {text_conf:.3f} | Image confidence: {img_conf:.3f}</p>

    <h3>Original Text</h3>
    <div class="text-box">{text}</div>

    <h3>Important Text Tokens</h3>
    <p>{token_html}</p>

    <h3>Image Explanation</h3>
    <div class="row">
        <div>
            <p>Original Image</p>
            <img src="data:image/png;base64,{img_to_html(np.array(raw_img))}" width="300">
        </div>
        <div>
            <p>Grad-CAM</p>
            <img src="data:image/png;base64,{img_to_html(overlay)}" width="300">
        </div>
    </div>
    </div>
    """

html += "</body></html>"
Path(OUTPUT_HTML).write_text(html, encoding="utf-8")

print("Explainability report generated:", OUTPUT_HTML)
