import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import pandas as pd
import os
from sklearn.metrics import confusion_matrix

# -------------------------------
# 1. PERFORMANCE METRICS DATA
# -------------------------------

pipelines = ['English Text', 'Multilingual Text', 'Image-only', 'Hybrid Fusion']
accuracy = [0.8157, 0.3392, 0.7015, 0.7364]
precision = [0.8148, 0.4976, 0.7200, 0.7042]
recall = [0.8157, 0.0558, 0.7000, 0.8085]
f1 = [0.8152, 0.1004, 0.6900, 0.7528]

# Create DataFrame
metrics_df = pd.DataFrame({
    'Pipeline': pipelines,
    'Accuracy': accuracy,
    'Precision': precision,
    'Recall': recall,
    'F1-score': f1
})

# -------------------------------
# 2. PERFORMANCE BAR PLOT
# -------------------------------
plt.figure(figsize=(10,6))
metrics_df.set_index('Pipeline').plot(kind='bar', figsize=(10,6))
plt.title("Performance Comparison Across Pipelines")
plt.ylabel("Score")
plt.ylim(0,1)
plt.xticks(rotation=0)
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.tight_layout()
plt.savefig("performance_comparison.png", dpi=600)
plt.close()

# -------------------------------
# 3. CLASS-WISE METRICS
# -------------------------------
# Example: English Text
class_metrics = {
    'English Text': {'REAL': {'Precision':0.7336,'Recall':0.7177}, 'FAKE': {'Precision':0.8565,'Recall':0.8660}},
    'Multilingual Text': {'REAL': {'Precision':0.33,'Recall':0.89}, 'FAKE': {'Precision':0.50,'Recall':0.06}},
    'Image-only': {'REAL': {'Precision':0.79,'Recall':0.54}, 'FAKE': {'Precision':0.65,'Recall':0.86}},
    'Hybrid Fusion': {'REAL': {'Precision':0.78,'Recall':0.67}, 'FAKE': {'Precision':0.70,'Recall':0.81}}
}

for model, data in class_metrics.items():
    labels = list(data.keys())
    precisions = [data[l]['Precision'] for l in labels]
    recalls = [data[l]['Recall'] for l in labels]
    
    x = np.arange(len(labels))
    width = 0.35
    
    fig, ax = plt.subplots(figsize=(8,5))
    ax.bar(x - width/2, precisions, width, label='Precision')
    ax.bar(x + width/2, recalls, width, label='Recall')
    ax.set_ylabel('Score')
    ax.set_ylim(0,1)
    ax.set_title(f'Class-wise Metrics for {model}')
    ax.set_xticks(x)
    ax.set_xticklabels(labels)
    ax.legend()
    ax.grid(axis='y', linestyle='--', alpha=0.7)
    plt.tight_layout()
    plt.savefig(f"class_metrics_{model.replace(' ','_')}.png", dpi=600)
    plt.close()

# -------------------------------
# 4. CONFUSION MATRIX PLOTS
# -------------------------------
# Example Confusion Matrices (replace with actual from your data)
conf_matrices = {
    'English Text': np.array([[694,273],[252,1629]]),
    'Multilingual Text': np.array([[861,106],[1776,105]]),
    'Image-only': np.array([[527,448],[137,838]]),
    'Hybrid Fusion': np.array([[652,328],[185,781]])
}

for model, cm in conf_matrices.items():
    plt.figure(figsize=(6,5))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues')
    plt.xlabel('Predicted Label')
    plt.ylabel('True Label')
    plt.title(f'Confusion Matrix - {model}')
    plt.tight_layout()
    plt.savefig(f"confusion_matrix_{model.replace(' ','_')}.png", dpi=600)
    plt.close()
