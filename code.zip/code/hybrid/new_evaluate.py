import torch
import torch.nn as nn
import pandas as pd
import numpy as np
from PIL import Image
from tqdm import tqdm

from transformers import AutoTokenizer, AutoModel
from torchvision import models, transforms

from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    classification_report,
    balanced_accuracy_score
)

# ================= CONFIG =================
TEST_FILE = r"C:\Users\Janvi\OneDrive\Desktop\Sem_8_Project\dataset\fakeddit\tsv\test_hybrid.tsv"
MODEL_PATH = r"C:\Users\Janvi\OneDrive\Desktop\Sem_8_Project\checkpoints\decision_fusion_best.pth"

BATCH_SIZE = 8
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("Using device:", DEVICE)

# ================= TRANSFORMS =================
image_transform = transforms.Compose([
    transforms.Resize((224,224)),
    transforms.ToTensor(),
    transforms.Normalize(
        mean=[0.485,0.456,0.406],
        std=[0.229,0.224,0.225]
    )
])

tokenizer = AutoTokenizer.from_pretrained("xlm-roberta-base")

# ================= DATASET =================
class HybridTestDataset(torch.utils.data.Dataset):
    def __init__(self, tsv):
        self.df = pd.read_csv(tsv, sep="\t")

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]

        encoding = tokenizer(
            row["clean_title"],
            padding="max_length",
            truncation=True,
            max_length=64,
            return_tensors="pt"
        )

        img = Image.open(row["image_path"]).convert("RGB")
        img = image_transform(img)

        return (
            encoding["input_ids"].squeeze(0),
            encoding["attention_mask"].squeeze(0),
            img,
            int(row["2_way_label"])
        )

# ================= MODELS =================
class TextModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.encoder = AutoModel.from_pretrained("xlm-roberta-base")
        self.fc = nn.Linear(768,2)

    def forward(self, ids, mask):
        out = self.encoder(input_ids=ids, attention_mask=mask)
        cls = out.last_hidden_state[:,0]
        return self.fc(cls)

class ImageModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.backbone = models.resnet50(weights="IMAGENET1K_V1")
        self.backbone.fc = nn.Linear(2048,2)

    def forward(self, x):
        return self.backbone(x)

# ================= LOAD MODELS =================
checkpoint = torch.load(MODEL_PATH, map_location=DEVICE)

text_model = TextModel().to(DEVICE)
image_model = ImageModel().to(DEVICE)

text_model.load_state_dict(checkpoint["text_model"])
image_model.load_state_dict(checkpoint["image_model"])

text_model.eval()
image_model.eval()

# ================= DATALOADER =================
test_loader = torch.utils.data.DataLoader(
    HybridTestDataset(TEST_FILE),
    batch_size=BATCH_SIZE,
    shuffle=False
)

# ================= EVALUATION =================
y_true, y_pred = [], []

with torch.no_grad():
    for ids, mask, img, label in tqdm(test_loader, desc="Evaluating"):
        ids = ids.to(DEVICE)
        mask = mask.to(DEVICE)
        img = img.to(DEVICE)

        text_logits = text_model(ids, mask)
        image_logits = image_model(img)

        fused_logits = (text_logits + image_logits) / 2
        preds = torch.argmax(fused_logits, dim=1).cpu().numpy()

        y_pred.extend(preds)
        y_true.extend(label.numpy())

# ================= METRICS =================
acc = accuracy_score(y_true, y_pred)
bal_acc = balanced_accuracy_score(y_true, y_pred)
prec = precision_score(y_true, y_pred)
rec = recall_score(y_true, y_pred)
f1 = f1_score(y_true, y_pred)
cm = confusion_matrix(y_true, y_pred)

print("\n========== FINAL DECISION FUSION RESULTS ==========\n")
print(f"Accuracy            : {acc:.4f}")
print(f"Balanced Accuracy   : {bal_acc:.4f}")
print(f"Precision           : {prec:.4f}")
print(f"Recall              : {rec:.4f}")
print(f"F1-score            : {f1:.4f}")

print("\nConfusion Matrix:")
print(cm)

print("\nClass-wise Report:")
print(classification_report(
    y_true,
    y_pred,
    target_names=["Real","Fake"]
))

print("\n===============================================\n")
